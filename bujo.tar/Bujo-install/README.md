#Bullet Journal
-------------

Writen by ndbest
nicholai.best@gmail.com
-------------

Bullet Journal(bujo) is a simple bash linux script with a few support files.  It is designed to be a 
bare bones digital equvilant of a bullet journal for terminal.  It automatically color
codes items based on syntax and can migrate tasks and meeting based on the date.

Download the tar file, and run 'sudo install.sh' to setup or
just read the install and put the files in your self!

After run 'bujo' to start right away or
'bujo -x' to run the tutorial program

Usage: bujo.sh [OPTION]
 use no option to open journal

 -s	print summary
 -a	print all tasks

 -i	print ! tasks
 -t	print * tasks
 -l	print *l tasks
 -m	print meetings
 -E	print things to be explored
 -e	print emails

 -n	start new day
 -d	edit daily tasks
 -h	print this text
 -x	open example format
